
import NpcCar from './npc_car.js';

export const createNpcCar = (initialX, initialY) => {
    return new NpcCar(initialX, initialY);
};